enum AnimType {
  herbivora,
  omnivora,
  karnivora
}

enum Family {
  Canidae,
  Tyrannosauridae,
  Salmonidae,
  Felidae,
  Equidae,
  Apidae,
  Culicidae,
  Sciuridae,
  Mammal
}