import 'package:flutter/cupertino.dart';

import 'FavoriteButtonState.dart';

class FavoriteButton extends StatefulWidget{

  FavoriteButton({Key? key}) : super(key:key);
  @override
  State<StatefulWidget> createState() {
    return FavoriteButtonState();
  }

}